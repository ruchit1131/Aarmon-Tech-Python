st = "11111000001111110000000011111111111000000001001010010100101010011101010010100"

"""
count = 0
i = 0
while True:
	if st[i]  == "1":
		count = count + 1
	i = i + 1
	if i > len(st) - 1 :
		break
print count
"""


