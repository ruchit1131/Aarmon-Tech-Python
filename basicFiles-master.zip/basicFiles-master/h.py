#
#
#

s = io.input(18)
count = 0
while True:
	s = io.input(18)
	if s == 1:
		count = count + 1
	print count
