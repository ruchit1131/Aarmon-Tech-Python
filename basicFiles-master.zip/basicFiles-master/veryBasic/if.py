"""print "Hello World"

a = raw_input("Enter a : ")
b = raw_input("Enter b : ")
c = int(a) + int(b)

print "Sum is : " + str(c)

if(c > 100):

	print "Greater than 100"

	if(c > 200):
		print "Greater than 200"
	print "Hello"

elif(c > 50):
	print "Greater than 50"
else:
	print "Smaller than 50"
print "End of Programe"
"""

print ("IF-ELSE")
a=int (input ("enter a :"))
b=int (input ("enter b :"))
c=a+b
print ("sum is c : " +str(c))

if(c < 10):
	print ("smaller than 10")
	print ("hello")
else: 
	print ("no value")
	print ("enter the value of >10")

